﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pub_base
{
    public class Pub
    {
        List<BeerKeg> supply;

        public Pub(List<BeerKeg> supply)
        {
            this.supply = supply;
        }
        public double Average()
        {
            double counter=0;
            foreach (BeerKeg b in supply)
            {
                counter += (b.Amount / b.Capacity);
            }

            return counter/supply.Count;
        }
        public void NewBeerKeg(BeerType bt, double amount, double capacity)
        {
            supply.Add(new BeerKeg(bt, capacity, amount));
        }
        public double MaxCapacity() {
            double max = double.MinValue;
            foreach(BeerKeg b in supply)
            {
                if (b.Capacity > max)
                {
                    max = b.Capacity;
                }
            }
        return max;
        }

    }
}
