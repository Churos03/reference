﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pub_base
{
    public abstract class BeerType
    {

        protected BeerType() { }
        public abstract double Factor();
        public virtual bool isIPA() {
            return false;
        }
        public double Price(double size) {
        return Factor()*size;
        }
    }
    public class IPA : BeerType { 
        public IPA() { }    
        public override double Factor()
        {
            return 1.5;
        }
        public override bool isIPA()
        {
            return true;    
        }
    }
    public class Wheat : BeerType
    {
        public Wheat() { }
        public override double Factor()
        {
            return 2.0;
        }

    }
    public class Lager : BeerType
    { public Lager() { }
        public override double Factor()
        {
            return 1.2;
        }

    }
}
