﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TextFile;

namespace Pub_base
{
    internal class Infile3
    {
        TextFileReader reader;
        public Infile3(string filename) 
        {
            reader = new TextFileReader(filename);
        }

        public Pub Read()
        {
            Pub p = new Pub(new List<BeerKeg>());
            reader.ReadInt(out int numberOfKegs);
            for(int i = 0; i < numberOfKegs; ++i)
            {
                reader.ReadDouble(out double capacity);
                reader.ReadDouble(out double amount);
                reader.ReadString(out string type);
                BeerType bt = null;
                switch(type)
                {
                    case "Lager":
                        bt = new Lager();
                        break;
                    case "IPA":
                        bt = new IPA();
                        break;
                    case "Wheat":
                        bt = new Wheat();
                        break;
                }
                p.NewBeerKeg(bt, capacity, amount);
            }
            return p;
        }
    }
}
