﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pub_base
{
    public class BeerKeg
    {
        BeerType type;
        private double amount;
        private double capacity;

        public BeerKeg(BeerType type, double amount, double capacity)
        {
            this.type = type;
            this.Amount = amount;
            this.Capacity = capacity;
        }

        public double Amount { get => amount; set => amount = value; }
        public double Capacity { get => capacity; set => capacity = value; }
    }
}
