﻿namespace Pub_base
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Infile3 infile = new Infile3("input.txt");  //Ha az ötöst csinálod, tedd kommentbe a sort
            //Infile5 infile = new Infile5("input.txt");//Ha az ötöst csinálod vedd ki kommentből a sort
                                                        //Infile5.cs TMS-en található, új inputfájllal együtt
            Pub p = infile.Read();
            Console.WriteLine(Math.Round(p.Average(),4));
            Console.WriteLine(p.MaxCapacity());
            //Console.WriteLine(p.IsOldestRegular()); //Ha az ötöst csinálod vedd ki kommentből a sort
        }
    }
}