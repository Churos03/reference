namespace Teniszklub
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestFizetaklubnak()
        {
            Klub klub = new Klub(new List<Klubtag>(), new List<P�lya>());
            Klubtag tag = new Klubtag("Szoszi", klub);
            P�lya p�lya = new Salak(3500, 1, true, new List<Foglal�s>());
            klub.ujpalya(p�lya);
            tag.foglal�s(p�lya, "2023.01.01.", 15);
            Assert.AreEqual(tag.Fizetaklubnak("2023.01.01."), 4200);
            Assert.AreEqual(tag.Fizetaklubnak("2023.01.02."), 0);
        }
        [TestMethod]
        public void TestOsszbevetel()
        {
            Klub klub = new Klub(new List<Klubtag>(), new List<P�lya>());
            Klubtag tag = new Klubtag("Szoszi", klub);
            klub.tagok.Add(tag);
            P�lya p�lya = new Salak(3500, 1, true, new List<Foglal�s>());
            klub.ujpalya(p�lya);
            tag.foglal�s(p�lya, "2023.01.01.", 15);
            Assert.AreEqual(klub.osszbevetel("2023.01.01."), 4200);
            Assert.AreEqual(klub.osszbevetel("2023.01.02."), 0);
        }
        [TestMethod]
        public void TestSzabadboritos()
        {
            Klub klub = new Klub(new List<Klubtag>(), new List<P�lya>());
            Klubtag tag = new Klubtag("Szoszi", klub);
            klub.tagok.Add(tag);
            P�lya p�lya = new Salak(3500, 1, true, new List<Foglal�s>());
            klub.ujpalya(p�lya);
            tag.foglal�s(p�lya, "2023.01.01.", 15);
            Assert.AreEqual(klub.szabadboritos(13, "2023.01.04,", "salakos")[0], p�lya );
            
        }
        [TestMethod]
        public void TestKlubtagfoglalt()
        {
            Klub klub = new Klub(new List<Klubtag>(), new List<P�lya>());
            Klubtag tag = new Klubtag("Szoszi", klub);
            klub.tagok.Add(tag);
            P�lya p�lya = new Salak(3500, 1, true, new List<Foglal�s>());
            klub.ujpalya(p�lya);
            tag.foglal�s(p�lya, "2023.01.01.", 15);
            Tuple<int,int> result=Tuple.Create(1,15);
            Assert.AreEqual(klub.Klubtagfoglalt(tag, "2023.01.01.")[0], result);

        }
        [TestMethod]
        public void TestOradij()
        {
            P�lya p�lya1 = new Salak(3500, 1, true, new List<Foglal�s>());
            P�lya p�lya2 = new F�ves(4000, 2, false, new List<Foglal�s>());
            Assert.AreEqual(p�lya1.�rad�j(), 3500 * 1.2);
            Assert.AreEqual(p�lya2.�rad�j(), 4000);
        }
    }
}