﻿namespace Teniszklub

{
    internal class Program
    {
        static void Main(string[] args)
        {
            Klub alapklub=new Klub(new List<Klubtag>(),new List<Pálya>());
            alapklub.beolvas("input.txt");
            Console.WriteLine(alapklub.tagok[2].Fizetaklubnak("2023.06.27"));
            Console.WriteLine(alapklub.osszbevetel("2023.06.27"));
            List<Pálya> res=alapklub.szabadboritos(12,"2023.06.27","füves");
            foreach(Pálya p in res)
            {
                Console.WriteLine(p.sorszám);
            }
            
            List<Tuple<int,int>> ls = alapklub.Klubtagfoglalt(alapklub.tagok[2], "2023.06.27");
            foreach (Tuple<int,int> item in ls)
            {
                Console.WriteLine(item.Item1 + " " + item.Item2);

            }
            
        }
    }
}