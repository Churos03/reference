﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using TextFile;
namespace Teniszklub
{
    public class Klub
    {
        public List<Klubtag> tagok;
        public List<Pálya> pályák;

        public Klub(List<Klubtag> tagok, List<Pálya> pályák)
        {
            this.tagok = tagok;
            this.pályák = pályák;
        }
        public void beolvas(string filename) {
            TextFileReader r = new TextFileReader(filename);
            string sline;
            while(r.ReadLine(out sline))
            {
                //Console.WriteLine(sline);
                string[] line=sline.Split(' ');    
            if (line[0] == "tag") {
                tagok.Add(new Klubtag(line[1],this));
            }
            if (line[0] == "palya")
            {
                switch (line[1])
                {
                    case "Fuves":
                        pályák.Add(new Füves(Convert.ToInt32(line[2]), Convert.ToInt32(line[3]), Convert.ToBoolean(line[4]),new List<Foglalás>()));
                        break;
                    case "Muanyag":
                        pályák.Add(new Műanyag(Convert.ToInt32(line[2]), Convert.ToInt32(line[3]), Convert.ToBoolean(line[4]), new List<Foglalás>()));
                        break;
                    case "Salak":
                        pályák.Add(new Salak(Convert.ToInt32(line[2]), Convert.ToInt32(line[3]), Convert.ToBoolean(line[4]), new List<Foglalás>()));
                        break;

                }
                           
            }
            if (line[0] == "foglalas")
            {
                Klubtag ktag = null;
                foreach(Klubtag k in tagok) {
                    if (k.név == line[4]) {
                        ktag = k; break;
                    }
                }
                Pálya p = null;
                foreach (Pálya pp in pályák)
                {
                    if (pp.sorszám == Convert.ToInt32(line[3]))
                    {
                        p= pp; break;
                    }
                }
                ktag.foglalás(p, line[1], Convert.ToInt32(line[2]));
                
            }
            }
        }
        public void ujpalya(Pálya pálya) {
            if (pályák.Contains(pálya))
            {
                throw new Exception();
            }
            else { pályák.Add(pálya); }
        }
        public void felszamolas(Pálya pálya)
        {
            if (!pályák.Contains(pálya))
            {
                throw new Exception();
            }
            else { pályák.Remove(pálya); }
        }
        public double osszbevetel(string date)
        {
            double osszbev = 0;
            foreach (Klubtag tag in tagok)
            {
                osszbev += tag.Fizetaklubnak(date);
            }
            return osszbev;
        }
        public List<Pálya> szabadboritos(int idopont, string datum, string boritas)
        {
            List<Pálya> result = new List<Pálya>();
            switch (boritas)
            {
                case "füves":
                    foreach (Pálya p in pályák)
                    {
                        if (!p.foglalt(datum, idopont))
                        { if (p.isFüves()) { result.Add(p); }
                        }
                    }
                    break;
                case "műanyag":
                    foreach (Pálya p in pályák)
                    {
                        if (!p.foglalt(datum, idopont))
                        {
                            if (p.isMűanyag()) { result.Add(p); }
                        }
                    }
                    break;
                case "salakos":
                    foreach (Pálya p in pályák)
                    {
                        if (!p.foglalt(datum, idopont))
                        {
                            if (p.isSalak()) { result.Add(p); }
                        }
                    }
                    break;

            }
            return result;
        }
        public List<Tuple<int,int>> Klubtagfoglalt(Klubtag tag, string date) 
        {
            List < Tuple<int, int> > result= new List<Tuple<int, int>>(); 
            foreach (Foglalás foglalás in tag.foglalások)
            {
                
                if (foglalás.dátum == date)
                {
                    result.Add(Tuple.Create(foglalás.pálya.sorszám, foglalás.idő));
                }
            }
            return result;
        }
    }
}
