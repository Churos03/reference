﻿using System.Linq;


namespace Teniszklub
{
    public class Klubtag
    {
        public string név;
        public List<Foglalás> foglalások;
        public Klub klub;

        public Klubtag(string név,Klub klub)
        {
            this.név = név;
            this.foglalások = new List<Foglalás>();
            this.klub = klub;
        }
        public void foglalás(Pálya pálya, string datum, int ido)
        {

            Foglalás ujfoglalas = new Foglalás(datum, ido, pálya);
            foreach(Foglalás f in pálya.pályafoglalások)
            {
                if(f.idő==ido && f.dátum==datum && f.pálya == pálya)
                {
                    throw new Exception();
                }
            }
            if(klub.pályák.Contains(pálya)) { foglalások.Add(ujfoglalas);
                 
                pálya.pályafoglalások.Add(ujfoglalas);


            }
            else {throw new Exception(); }  
            
        }
        public void lemondás(Foglalás lemondott)
        {
            if (foglalások.Contains(lemondott))
            {
                foglalások.Remove(lemondott);
                lemondott.pálya.pályafoglalások.Remove(lemondott);
            }
            else
            {
                throw new Exception();
            }

        }
        public void belép(Klub klub)
        {
            if (klub != null)
            {
                throw new Exception();
            }
            else { this.klub = klub!;
            klub.tagok.Add(this);
            }
        }
        public void kilep()
        {
            if (klub==null)
            {
                throw new Exception();
            }
            else { this.klub = null!;
                klub.tagok.Remove(this);
            }
        }
        public double Fizetaklubnak(string date)
        {
            double price = 0;
            foreach(Foglalás foglalás in foglalások)
            {
                if (date == foglalás.dátum) { price += foglalás.pálya.óradíj(); }
                
            }
            return price;
        }
    }
}
