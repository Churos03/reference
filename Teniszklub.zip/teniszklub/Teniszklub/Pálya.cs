﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;


namespace Teniszklub
{
    public abstract class Pálya
    {
        public int ár;
        public int sorszám;
        public bool fedett;
        public List<Foglalás> pályafoglalások;    
        public Pálya(int ár, int sorszám, bool fedett,List<Foglalás> foglalások)
        {
            this.ár = ár;
            this.sorszám = sorszám;
            this.fedett = fedett;
            this.pályafoglalások = foglalások;
        }
        public virtual bool isFüves()
        {
            return false;
        }
        public virtual bool isSalak()
        {
            return false;
        }
        public virtual bool isMűanyag()
        {
            return false;
        }
        public abstract double Szorzó();
        public double óradíj()
        {
            return ár * Szorzó();
        }
        public bool foglalt(string date, int time)
        {
            bool isfoglalt = false;
             foreach(Foglalás foglalas in pályafoglalások)
            {
                if(foglalas.dátum==date && foglalas.idő == time)
                {
                    isfoglalt = true;
                }
            }

            return isfoglalt;
        }

    }
    public class Füves : Pálya
    {
        public Füves(int ár, int sorszám, bool fedett, List<Foglalás> foglalások) : base(ár, sorszám, fedett, foglalások)
        {
        }

        public override double Szorzó()
        {
            return fedett ? 1.2 : 1.0;
        }
        public override bool isFüves()
        {
            return true;
        }
    }
    public class Salak : Pálya
    {
        public Salak(int ár, int sorszám, bool fedett, List<Foglalás> foglalások) : base(ár, sorszám, fedett, foglalások)
        {
        }

        public override double Szorzó()
        {
            return fedett ? 1.2 : 1.0;
        }
        public override bool isSalak()
        {
            return true;
        }
    }
    public class Műanyag : Pálya
    {
        public Műanyag(int ár, int sorszám, bool fedett, List<Foglalás> foglalások) : base(ár, sorszám, fedett, foglalások)
        {
        }

        public override double Szorzó()
        {
            return fedett ? 1.2 : 1.0;
        }
        public override bool isMűanyag()
        {
            return true;
        }
    }


}
