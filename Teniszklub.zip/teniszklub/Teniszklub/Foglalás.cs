﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Teniszklub
{
    public class Foglalás
    {
        public string dátum;
        public int idő;
        public Pálya pálya;

        public Foglalás(string dátum, int idő, Pálya pálya)
        {
            this.dátum = dátum;
            this.idő = idő;
            this.pálya = pálya;
        }
    }
}
